<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/prime.gifts/admin/gifts_edit.php");
?>