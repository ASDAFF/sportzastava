drop table if exists b_prime_gifts;
drop table if exists b_prime_gifts_settings;