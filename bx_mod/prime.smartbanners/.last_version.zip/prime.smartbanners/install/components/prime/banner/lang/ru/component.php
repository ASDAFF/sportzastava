<?
//$MESS["COMPONENT_NAME"] = "Галлерея пользователя";
?>