<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/prime.smartbanners/admin/s_banner_list.php");
?>