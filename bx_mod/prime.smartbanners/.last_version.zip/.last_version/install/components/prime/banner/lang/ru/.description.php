<?
$MESS["COMPONENT_NAME"] = "РЈРјРЅС‹Р№ Р±Р°РЅРЅРµСЂ";
$MESS["COMPONENT_DESCRIPTION"] = "РџРѕРєР°Р· Р±Р°РЅРЅРµСЂР° РЅР° СЃС‚СЂР°РЅРёС†Рµ";
$MESS["COMPONENT_MENU_NAME"] = "Prime";
?>