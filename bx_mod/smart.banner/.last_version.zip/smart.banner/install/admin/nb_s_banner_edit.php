<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/smart.banner/admin/s_banner_edit.php");
?>