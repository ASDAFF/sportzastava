<?
$MESS["COMPONENT_NAME"] = "Умный баннер";
$MESS["COMPONENT_DESCRIPTION"] = "Показ баннера на странице";
$MESS["COMPONENT_MENU_NAME"] = "Prime";
?>