<?
${"alexkova.rklite_default_option"} = array(
	"PARAM_R1" => "r1, ref1, referer1",
	"PARAM_R2" => "",
	"STAT_DAYS" =>30
);
?>